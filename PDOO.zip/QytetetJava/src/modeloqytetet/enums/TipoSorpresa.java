
package modeloqytetet.enums;

public enum TipoSorpresa {
    PAGARCOBRAR, IRACASILLA, PORCASAHOTEL, PORJUGADOR, SALIRCARCEL
}