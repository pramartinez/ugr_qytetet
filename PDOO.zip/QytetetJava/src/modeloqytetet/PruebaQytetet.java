
package modeloqytetet;
import java.util.ArrayList;
import modeloqytetet.enums.TipoSorpresa;

public class PruebaQytetet {
    private static ArrayList<Sorpresa> mazo = new ArrayList();
    
    private static void inicializarSorpresas() {        
        mazo.add(new Sorpresa("", 17, TipoSorpresa.IRACASILLA));
        mazo.add(new Sorpresa("", 11, TipoSorpresa.IRACASILLA));
        mazo.add(new Sorpresa("", 0, TipoSorpresa.SALIRCARCEL));
        mazo.add(new Sorpresa("", 0, TipoSorpresa.SALIRCARCEL));
        mazo.add(new Sorpresa("", 250, TipoSorpresa.PORJUGADOR));
        mazo.add(new Sorpresa("¡Es tu día de suerte! Cada jugador ha de pagarte"
                + "un euro.", 1, TipoSorpresa.PORJUGADOR));
        mazo.add(new Sorpresa("", 200, TipoSorpresa.PAGARCOBRAR));
        mazo.add(new Sorpresa("", 175, TipoSorpresa.PAGARCOBRAR));
        mazo.add(new Sorpresa("", 30, TipoSorpresa.PORCASAHOTEL));
        mazo.add(new Sorpresa("", 50, TipoSorpresa.PORCASAHOTEL));
    }
    
    public static ArrayList getSorpresasMayor0() {
        ArrayList <Sorpresa> sorpresas_mayores = new ArrayList();
        
        for (Sorpresa s : mazo){
            if(s.getValor() > 0)
                sorpresas_mayores.add(s);
        }
        return sorpresas_mayores;
    }
    
    public static ArrayList getSorpresasIrACasilla() {
        ArrayList <Sorpresa> sorpresas_iracasilla = new ArrayList();
        
        sorpresas_iracasilla = getSorpresas(TipoSorpresa.IRACASILLA);
        
        return sorpresas_iracasilla;        
    }
    
    public static ArrayList getSorpresas(TipoSorpresa un_tipo) {
        ArrayList <Sorpresa> sorpresas_tipo = new ArrayList();
        
        for (Sorpresa s : mazo){
            if(s.getTipo() == un_tipo)
                sorpresas_tipo.add(s);
        }
        return sorpresas_tipo;         
    }
    
    public static void main(String[] args) {
        inicializarSorpresas();
        System.out.print(mazo.toString());
        System.out.print("\n");
        
        ArrayList <Sorpresa> array_sorpresas = getSorpresasMayor0();
        System.out.print(array_sorpresas.toString());
        System.out.print("\n");
        
        array_sorpresas = getSorpresasIrACasilla();
        System.out.print(array_sorpresas.toString());
        System.out.print("\n");
        
        array_sorpresas = getSorpresas(TipoSorpresa.SALIRCARCEL);
        System.out.print(array_sorpresas.toString());
          
    }
    
}
