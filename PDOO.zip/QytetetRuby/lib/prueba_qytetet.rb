# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module ModeloQytetet
  require_relative 'tipo_sorpresa'

  class PruebaQytetet
    @@mazo = Array.new

    def self.inicializar_sorpresa
      mazo << Sorpresa.new("Ha pagado tu fianza. Sales de la cárcel",
        0, TipoSorpresa::SALIRCARCEL)
      mazo << Sorpresa.new("Ha pagado tu fianza. Sales de la cárcel",
        0, TipoSorpresa::SALIRCARCEL)
      mazo << Sorpresa.new("Ha pagado tu fianza. Sales de la cárcel",
        0, TipoSorpresa::PAGARCOBRAR)
      mazo << Sorpresa.new("Ha pagado tu fianza. Sales de la cárcel",
        0, TipoSorpresa::PAGARCOBRAR)
      mazo << Sorpresa.new("Ha pagado tu fianza. Sales de la cárcel",
        0, TipoSorpresa::PORJUGADOR)
      mazo << Sorpresa.new("Ha pagado tu fianza. Sales de la cárcel",
        0, TipoSorpresa::PORJUGADOR)
      mazo << Sorpresa.new("Ha pagado tu fianza. Sales de la cárcel",
        0, TipoSorpresa::IRACASILLA)
      mazo << Sorpresa.new("Ha pagado tu fianza. Sales de la cárcel",
        0, TipoSorpresa::IRACASILLA)
      mazo << Sorpresa.new("Ha pagado tu fianza. Sales de la cárcel",
        0, TipoSorpresa::PORCASAHOTEL)
      mazo << Sorpresa.new("Ha pagado tu fianza. Sales de la cárcel",
        0, TipoSorpresa::PORCASAHOTEL)
    end

    # Devuelve una lista con las sorpresas cuyo valor es mayor que 0
    def self.get_sorpresas_mayor_cero
      for s in @@mazo
        if s.valor > 0
          sorpresas << s
        end
      end
    end

    # Devuelve una lista con las sorpresas del tipo IR_A_CASILLA
    def self.get_sorpresas_ir_a_casilla
      return get_sorpresas(TipoSorpresa::IRACASILLA)
    end

    # Devuelve una lista de sorpresas según el criterio (tipo)
    def self.get_sorpresas(tipo)
      sorpresas = Array.new

      for s in @@mazo
        if s.tipo == tipo
          sorpresas << s
        end
      end

      return sorpresas
    end
  end
end