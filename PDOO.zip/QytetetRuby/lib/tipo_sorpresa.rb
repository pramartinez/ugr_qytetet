# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module ModeloQytetet
  module TipoSorpresa
    PAGARCOBRAR  = :PagarCobrar
    IRACASILLA   = :IrACasilla
    SALIRCARCEL  = :SalirCarcel
    PORJUGADOR   = :PorJugador
    PORCASAHOTEL = :PorCasaHotel
  end
end
